import { useEffect, useState } from "react";

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then(res => res.json())
      .then(setProducts);
  }, []);

  const addToCart = (p) => setCart([...cart, p]);

  const checkout = async () => {
    await fetch("http://localhost:5000/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: cart,
        total: cart.reduce((a,b)=>a+b.price,0)
      })
    });
    alert("Order placed!");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>ekO Store</h1>

      <div>
        {products.map(p => (
          <div key={p.id}>
            <h3>{p.name}</h3>
            <p>R{p.price}</p>
            <button onClick={() => addToCart(p)}>Add</button>
          </div>
        ))}
      </div>

      <h2>Cart: {cart.length}</h2>
      <button onClick={checkout}>Checkout</button>
    </div>
  );
}
