const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let products = [
  { id: 1, name: "Minimal Jacket", price: 1200 },
  { id: 2, name: "Street Hoodie", price: 800 }
];

let orders = [];

app.get("/products", (req, res) => {
  res.json(products);
});

app.post("/products", (req, res) => {
  products.push({ id: Date.now(), ...req.body });
  res.json({ success: true });
});

app.post("/orders", (req, res) => {
  const order = {
    id: Date.now(),
    items: req.body.items,
    total: req.body.total,
    status: "pending"
  };
  orders.push(order);
  res.json(order);
});

app.get("/orders", (req, res) => {
  res.json(orders);
});

app.listen(5000, () => console.log("Server running on port 5000"));
