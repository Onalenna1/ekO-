# ekO Full Stack Ecommerce

## Setup

### Backend
cd server
npm install
npm start

### Frontend
cd client
npm install
npm start

## Features
- Product listing
- Cart system
- Order creation
- Basic backend API
